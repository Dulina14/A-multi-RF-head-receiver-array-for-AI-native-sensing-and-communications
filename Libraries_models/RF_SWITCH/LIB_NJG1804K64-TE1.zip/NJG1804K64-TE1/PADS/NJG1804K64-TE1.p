*PADS-LIBRARY-PART-TYPES-V9*

NJG1804K64-TE1 NJG1804K64TE1 I ANA 7 1 0 0 0
TIMESTAMP 2026.11.24.05.57.37
"Mouser Part Number" 513-NJG1804K64-TE1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nisshinbo/NJG1804K64-TE1?qs=G%2F5vCLrg9vwbU49hoKahVg%3D%3D
"Manufacturer_Name" Nisshinbo
"Manufacturer_Part_Number" NJG1804K64-TE1
"Description" RF Switch IC 802.11a/b/g/n/ac, Bluetooth SP3T 50Ohm 8-DFN (1.5x1.5),-40C ~ 105C,1.9V ~ 5V
"Datasheet Link" https://www.nisshinbo-microdevices.co.jp/en/pdf/datasheet/NJG1804K64_E.pdf
"Geometry.Height" 0.425mm
GATE 1 9 0
NJG1804K64-TE1
1 0 U PC
2 0 U NC
3 0 U VCTL1
4 0 U P1
5 0 U P2
6 0 U VCTL2
7 0 U VCTL3
8 0 U P3
9 0 U GND

*END*
*REMARK* SamacSys ECAD Model
20401914/1624870/2.50/9/3/Integrated Circuit
